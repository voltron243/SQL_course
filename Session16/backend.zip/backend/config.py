MYSQL_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '00000000',
    'database': 'SQLCourse',
    'port': 3306,
    'charset': 'utf8mb4'
}

FLASK_CONFIG = {
    'host': '0.0.0.0',
    'port': 8080,
    'debug': True
}
